//a variable can be declared by 3 key words - var, let and const.
var x="pritam";
let y="rahul";
const z="ganesh";
console.log(x);
console.log(y);
console.log(z);

//output is:
// pritam
// rahul
// ganesh