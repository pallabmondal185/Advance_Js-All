// if the numbe of data is known then for loop is used.
// if number of data is not known then while loop is used.

console.log("example of for loop");
for(let i=0;i<=5;i++){
console.log(i);
}


console.log("example of while loop.");
let i=0;
while(i!=6){
    console.log(i)
    i++;
}

// in both case output is:
// 0
// 1
// 2
// 3
// 4
// 5