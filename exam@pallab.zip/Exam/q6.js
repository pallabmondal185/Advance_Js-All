var st="welcome to webskitter";
console.log(st.slice(3,8));
//output is: come

var st="welcome to webskitter";
console.log(st.replace("to","here"));
// output is: welcome here webskitter

console.log(st.toUpperCase());
// outpit is: WELCOME TO WEBSKITTER

var st1="HELLO WORLD";
console.log(st1.toLowerCase());
// output is: hello world

console.log(st.concat(st1));
// output: welcome to webskitterHELLO WORLD

var st2="pall    a    n    mon   dal"
console.log(st2.trim());