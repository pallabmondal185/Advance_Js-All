let names=["pritam","ganesh","rahul"];

console.log(names.toString());

console.log(names.join("*"));

let fruits=["apple","orange","mango"];
console.log(names.concat(fruits));

let names1=["pritam","ganesh","rahul"];
console.log(names1.pop());
console.log(names1);

let names2=["pritam","ganesh","rahul"];
console.log(names2.push("malay"));
console.log(names2);

let names3=["pritam","ganesh","rahul"];
names3.shift("sauvik");
console.log(names3);